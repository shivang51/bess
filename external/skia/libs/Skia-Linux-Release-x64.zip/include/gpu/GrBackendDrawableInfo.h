/*
 * Copyright 2018 Google Inc.
 *
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */

// TODO(kjlubick) delete after Chrome (and Android?) are migrated.
#include "include/gpu/ganesh/vk/GrBackendDrawableInfo.h"
