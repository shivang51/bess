/*
 * Copyright 2020 Google Inc.
 *
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */

// TODO(kjlubick,jvanverth) Remove this shim file after updating clients
#include "include/gpu/ganesh/mtl/GrMtlBackendContext.h"
